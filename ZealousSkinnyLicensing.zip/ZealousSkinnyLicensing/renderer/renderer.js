document.getElementById('detectBtn').addEventListener('click', async () => {
  const info = await window.api.getSystemInfo();
  const display = `CPU: ${info.cpu}\nGPU: ${info.gpu}\n内存: ${info.memory}\n分辨率: ${info.resolution}`;
  document.getElementById('result').innerText = display;
});